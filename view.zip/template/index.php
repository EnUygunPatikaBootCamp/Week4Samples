<?php
include 'Template.php';
Template::view('index.html');
?>